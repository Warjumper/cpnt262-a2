# cpnt262-a2
## Assignment 2 - If This, Then That (forms)

#### by jesse H

### GitHub Pages - https://warjumper.github.io/cpnt262-a2/

#### Code attributions;

- Katherine helped me a ton with debugging some issues (great second set of eyes!) and some JS help.
- Some image change ideas - https://stackoverflow.com/questions/17717525/changing-image-based-on-form-selection
- https://css-tricks.com/replace-the-image-in-an-img-with-css/
- https://stackoverflow.com/questions/6235224/changing-color-by-javascript-function
- images from https://www.pexels.com/